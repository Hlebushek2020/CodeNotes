﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace SymbolicConverter
{
    internal class Program
    {
        private const string attrKey = " ATTRIBUTE_";
        private const string relKey = " RELATIONSHIP_";

        private static List<string> original = new List<string>();

        static void Main(string[] args)
        {
            string readFile = Console.ReadLine();
            using (StreamReader streamReader = new StreamReader(readFile, Encoding.UTF8))
            {
                while (!streamReader.EndOfStream)
                {
                    original.Add(streamReader.ReadLine());
                }
            }
            string writeFile = Path.Combine(Path.GetDirectoryName(readFile), $"out_{Path.GetFileName(readFile)}");
            using (StreamWriter streamWriter = new StreamWriter(writeFile, false, Encoding.UTF8))
            {
                for (int numOrig = 0; numOrig < original.Count - 1; numOrig++)
                {
                    string line_1 = original[numOrig];
                    string line_2 = original[numOrig + 1];
                    SymbolicInfo symbolicInfo = new SymbolicInfo();
                    if (line_1.Contains(attrKey))
                    {
                        symbolicInfo.FromName = line_1.Substring(line_1.IndexOf(attrKey) + 1);
                        int count = symbolicInfo.FromName.IndexOf('=') - 1;
                        if (count != -1)
                        {
                            symbolicInfo.FromName = symbolicInfo.FromName.Substring(0, count);
                        }

                    }
                    else if (line_1.Contains(relKey))
                    {
                        symbolicInfo.FromName = line_1.Substring(line_1.IndexOf(relKey) + 1);
                        int count = symbolicInfo.FromName.IndexOf('=') - 1;
                        if (count != -1)
                        {
                            symbolicInfo.FromName = symbolicInfo.FromName.Substring(0, count);
                        }
                    }
                    try
                    {
                        if (line_1.Contains('"'))
                        {
                            int startIndex = line_1.IndexOf('"') + 1;
                            int count = line_1.LastIndexOf('"') - startIndex;
                            symbolicInfo.Value = line_1.Substring(startIndex, count);
                            symbolicInfo.Validation();

                            streamWriter.Write("public static final String SYMBOLIC_");
                            streamWriter.Write(symbolicInfo.FromName);
                            streamWriter.Write("=\"");
                            streamWriter.Write(symbolicInfo.Value);
                            streamWriter.WriteLine("\";");

                            streamWriter.Write("public static final String ");
                            streamWriter.Write(symbolicInfo.FromName);
                            streamWriter.Write("=PropertyUtil.getSchemaProperty(SYMBOLIC_");
                            streamWriter.Write(symbolicInfo.FromName);
                            streamWriter.WriteLine(");");

                        }
                        else if (line_2.Contains('"'))
                        {

                            int startIndex = line_2.IndexOf('"') + 1;
                            int count = line_2.LastIndexOf('"') - startIndex;
                            symbolicInfo.Value = line_2.Substring(startIndex, count);
                            symbolicInfo.Validation();

                            streamWriter.Write("public static final String SYMBOLIC_");
                            streamWriter.Write(symbolicInfo.FromName);
                            streamWriter.Write("=\"");
                            streamWriter.Write(symbolicInfo.Value);
                            streamWriter.WriteLine("\";");

                            streamWriter.Write("public static final String ");
                            streamWriter.Write(symbolicInfo.FromName);
                            streamWriter.Write("=PropertyUtil.getSchemaProperty(SYMBOLIC_");
                            streamWriter.Write(symbolicInfo.FromName);
                            streamWriter.WriteLine(");");

                            numOrig++;
                        }
                        else
                        {
                            streamWriter.WriteLine(line_1);
                        }
                    }
                    catch
                    {
                        streamWriter.WriteLine(line_1);
                    }
                }
            }
        }

        public class SymbolicInfo
        {
            public string FromName;
            public string Value;

            public void Validation()
            {
                if (string.IsNullOrWhiteSpace(FromName) || string.IsNullOrWhiteSpace(Value))
                {
                    throw new Exception();
                }
            }
        }
    }
}