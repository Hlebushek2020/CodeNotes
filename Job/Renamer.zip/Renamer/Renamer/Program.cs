﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Renamer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Resources folder: ");
            string directoryPath = Console.ReadLine();
            //@"C:\Users\serge\Downloads\classes";
            string outDir = directoryPath + "_out";
            Directory.CreateDirectory(outDir);
            Console.Write("Search word: ");
            string containsWord = Console.ReadLine();
            //"собран";
            DirectoryInfo directory = new DirectoryInfo(directoryPath);
            FileInfo[] fileInfos = directory.GetFiles("emx*StringResource_ruNative*");
            Dictionary<string, List<string>> linesInFiles = new Dictionary<string, List<string>>();
            foreach (FileInfo info in fileInfos)
            {
                List<string> lines = new List<string>();
                Console.WriteLine("Read: " + info.Name);
                StreamReader fileReader = new StreamReader(info.FullName, Encoding.UTF8);
                while (!fileReader.EndOfStream)
                {
                    string lineFromFile = fileReader.ReadLine();
                    if (lineFromFile.ToLower().Contains(containsWord))
                    {
                        lines.Add(lineFromFile);
                    }
                }
                linesInFiles.Add(info.FullName, lines);
            }
            Dictionary<string, string> replaceItems = new Dictionary<string, string>();
            foreach (KeyValuePair<string, List<string>> keyValuePair in linesInFiles)
            {
                Console.WriteLine(new string('=', 30));
                Console.WriteLine($"Total: {keyValuePair.Value.Count}");
                foreach (string stringRes in keyValuePair.Value)
                {
                    int startIndex = stringRes.ToLower().IndexOf(containsWord);
                    int endIndex = stringRes.IndexOf(' ', startIndex);
                    if (endIndex == -1)
                    {
                        endIndex = stringRes.Length;
                    }
                    string replaceWord = stringRes.Substring(startIndex, endIndex - startIndex);
                    if (!replaceItems.ContainsKey(replaceWord))
                    {
                        Console.WriteLine(new string('=', 30));
                        Console.WriteLine(stringRes);
                        Console.WriteLine("From: " + replaceWord);
                        Console.Write($"To (enter the value, default: {replaceWord}): ");
                        string toWord = Console.ReadLine();
                        replaceItems.Add(replaceWord, string.IsNullOrEmpty(toWord) ? replaceWord : toWord);
                    }
                }
            }
            foreach (KeyValuePair<string, List<string>> keyValuePair in linesInFiles)
            {
                if (keyValuePair.Value.Count > 0)
                {
                    using StreamWriter streamWriter =
                        new StreamWriter(Path.Combine(outDir, Path.GetFileName(keyValuePair.Key)), false,
                            Encoding.UTF8);
                    foreach (string stringRes in keyValuePair.Value)
                    {
                        string result = stringRes;
                        foreach (KeyValuePair<string, string> replaceItem in replaceItems)
                        {
                            result = result.Replace(replaceItem.Key, replaceItem.Value);
                        }
                        streamWriter.WriteLine(result);
                    }
                }
            }
        }
    }
}